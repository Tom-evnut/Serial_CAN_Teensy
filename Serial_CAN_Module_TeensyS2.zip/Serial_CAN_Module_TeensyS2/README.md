More details please goto [Longan Labs](https://longan-labs.cc/serial-can-bus/)

[![Analytics](https://ga-beacon.appspot.com/UA-101965714-1/Serial_CAN_Arduino)](https://github.com/igrigorik/ga-beacon)
